package org.levimc.launcher.core.mods;

import android.content.Context;
import android.os.Looper;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import org.levimc.launcher.core.versions.GameVersion;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Installs the Volt optimizer that ships inside the APK (asset {@link #VOLT_ASSET}) into the mods
 * directory of one specific Minecraft version.
 *
 * Design notes
 * - The target is always the {@link GameVersion} passed in (the version about to launch, or the
 *   one selected in the UI), never a guessed global "selected" version.
 * - Installation goes through {@link FileHandler#installPackageHeadless}, which reuses the
 *   importer's validation and extraction, so a bundled install is identical to a manual import.
 * - Nothing here touches mods_config.json. ModManager registers a newly discovered mod as enabled
 *   and keeps any later user choice (disabled, reordered) on its own.
 * - Idempotent. Per mods directory a small state file records what happened, so Volt is not
 *   reinstalled after the user deletes it, not re-enabled after they disable it, not downgraded,
 *   and a failing install is retried only a couple of times.
 * - Blocking work. Call {@link #ensureVoltInstalled} from a background thread; use
 *   {@link #ensureVoltInstalledAsync} from UI code. All entry points share one lock, so the launch
 *   flow simply waits for an install that is already in progress.
 */
public final class BundledModInstaller {
    private static final String TAG = "BundledModInstaller";

    /** Asset path of the bundled package (see bundled-mods/ in app/build.gradle). */
    static final String VOLT_ASSET = "Ace-Volt-2.3.2.levipack";
    static final String VOLT_ID = "Volt";
    static final String VOLT_VERSION = "2.3.2";
    /**
     * Minecraft versions this Volt build targets (its manifest says "Minecraft Bedrock 1.26.52").
     * Written into the installed manifest as minecraft_versions so the existing loader also skips
     * it on any other version. Same pattern syntax as other mods.
     */
    static final List<String> VOLT_MINECRAFT_VERSIONS =
            Collections.unmodifiableList(Arrays.asList("1.26.52", "1.26.52.*"));

    private static final String STATE_FILE = ".ace-bundled-mods.json";
    private static final String STATE_INSTALLED = "installed";
    private static final String STATE_FAILED = "failed";
    private static final int MAX_FAILED_ATTEMPTS = 2;

    private static final Object LOCK = new Object();
    private static final Gson GSON = new Gson();
    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "bundled-mod-installer");
        t.setDaemon(true);
        return t;
    });

    public enum Result {
        INSTALLED,
        REPAIRED,
        ALREADY_PRESENT,
        NEWER_PRESENT,
        SKIPPED_REMOVED_BY_USER,
        SKIPPED_INCOMPATIBLE_VERSION,
        SKIPPED_NO_MODS_DIR,
        SKIPPED_MAIN_THREAD,
        SKIPPED_TOO_MANY_FAILURES,
        FAILED
    }

    /** Persisted per mods directory. Read/written with explicit JSON keys so R8 renaming is harmless. */
    private static final class State {
        String state;
        String bundledVersion;
        int attempts;
    }

    private static final class Existing {
        final boolean valid;
        final String version;

        Existing(boolean valid, String version) {
            this.valid = valid;
            this.version = version;
        }
    }

    private BundledModInstaller() {}

    /** Fire-and-forget variant for UI code. Refreshes the Mods list when something changed. */
    public static void ensureVoltInstalledAsync(Context context, GameVersion version) {
        final Context appContext = context.getApplicationContext();
        EXECUTOR.execute(() -> {
            try {
                ensureVoltInstalled(appContext, version);
            } catch (Throwable t) {
                Log.e(TAG, "Unexpected error while checking bundled Volt", t);
            }
        });
    }

    /**
     * Makes sure Volt is installed for {@code version}. Never throws; failures are logged and
     * reported through the result, and the manual Mods import keeps working either way.
     */
    public static Result ensureVoltInstalled(Context context, GameVersion version) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            Log.w(TAG, "Refusing to run bundled mod install on the main thread");
            return Result.SKIPPED_MAIN_THREAD;
        }
        if (version == null || version.modsDir == null) {
            return Result.SKIPPED_NO_MODS_DIR;
        }
        if (!ModNativeLoader.isCompatibleWithMinecraftVersion(VOLT_MINECRAFT_VERSIONS, version.versionCode)) {
            Log.i(TAG, "Not installing Volt for Minecraft " + version.versionCode
                    + " (built for " + VOLT_MINECRAFT_VERSIONS + ")");
            return Result.SKIPPED_INCOMPATIBLE_VERSION;
        }

        synchronized (LOCK) {
            File modsDir = version.modsDir;
            File tempPackage = null;
            try {
                if (!modsDir.isDirectory() && !modsDir.mkdirs()) {
                    Log.w(TAG, "Could not create mods directory for " + version.directoryName);
                    return Result.SKIPPED_NO_MODS_DIR;
                }

                State state = readState(modsDir);
                File voltDir = new File(modsDir, VOLT_ID);
                Existing existing = findInstalledVolt(modsDir, voltDir);

                if (existing.valid) {
                    int cmp = compareVersions(existing.version, VOLT_VERSION);
                    if (state == null || !STATE_INSTALLED.equals(state.state)) {
                        writeState(modsDir, STATE_INSTALLED, existing.version, 0);
                    }
                    return cmp > 0 ? Result.NEWER_PRESENT : Result.ALREADY_PRESENT;
                }

                boolean needsRepair = voltDir.exists();
                if (!needsRepair && state != null && STATE_INSTALLED.equals(state.state)) {
                    // We installed it before and the folder is now gone: the user removed it.
                    return Result.SKIPPED_REMOVED_BY_USER;
                }
                if (state != null && STATE_FAILED.equals(state.state)
                        && VOLT_VERSION.equals(state.bundledVersion)
                        && state.attempts >= MAX_FAILED_ATTEMPTS) {
                    return Result.SKIPPED_TOO_MANY_FAILURES;
                }

                try {
                    tempPackage = copyAssetToCache(context);
                    FileHandler.HeadlessInstallResult installed = new FileHandler(context, modsDir)
                            .installPackageHeadless(tempPackage, needsRepair, VOLT_MINECRAFT_VERSIONS);
                    Existing after = inspect(new File(modsDir, installed.modId));
                    if (!after.valid) {
                        throw new IOException("Volt not recognised after install");
                    }
                    writeState(modsDir, STATE_INSTALLED, VOLT_VERSION, 0);
                    ModManager.getInstance().refreshMods();
                    Log.i(TAG, "Volt " + (installed.repairedExisting ? "repaired" : "installed")
                            + " for " + version.directoryName);
                    return installed.repairedExisting ? Result.REPAIRED : Result.INSTALLED;
                } catch (Throwable error) {
                    Log.e(TAG, "Automatic Volt install failed for " + version.directoryName, error);
                    int attempts = (state != null && STATE_FAILED.equals(state.state)
                            && VOLT_VERSION.equals(state.bundledVersion)) ? state.attempts + 1 : 1;
                    writeState(modsDir, STATE_FAILED, VOLT_VERSION, attempts);
                    return Result.FAILED;
                }
            } catch (Throwable t) {
                Log.e(TAG, "Bundled Volt check failed", t);
                return Result.FAILED;
            } finally {
                if (tempPackage != null && tempPackage.exists() && !tempPackage.delete()) {
                    Log.w(TAG, "Could not delete temporary package");
                }
            }
        }
    }

    /**
     * Finds a usable Volt anywhere in the mods directory: the default "Volt" folder first, then any
     * other folder whose manifest is named Volt (e.g. a manual import that got a suffixed folder),
     * so a bundled install never creates a duplicate entry.
     */
    private static Existing findInstalledVolt(File modsDir, File defaultDir) {
        Existing primary = inspect(defaultDir);
        if (primary.valid) {
            return primary;
        }
        File[] children = modsDir.listFiles(File::isDirectory);
        if (children == null) {
            return primary;
        }
        for (File child : children) {
            if (child.equals(defaultDir)) {
                continue;
            }
            File manifestFile = new File(child, "manifest.json");
            if (!manifestFile.isFile()) {
                continue;
            }
            try (InputStreamReader reader = new InputStreamReader(
                    new java.io.FileInputStream(manifestFile), StandardCharsets.UTF_8)) {
                JsonObject manifest = GSON.fromJson(reader, JsonObject.class);
                if (manifest != null && manifest.has("name") && manifest.get("name").isJsonPrimitive()
                        && VOLT_ID.equalsIgnoreCase(manifest.get("name").getAsString().trim())) {
                    Existing candidate = inspect(child);
                    if (candidate.valid) {
                        return candidate;
                    }
                }
            } catch (Exception ignored) {
                // Unreadable manifests belong to other mods; ModManager ignores them as well.
            }
        }
        return primary;
    }

    /** Reads the Volt folder's manifest the same way ModManager does (type + entry file present). */
    private static Existing inspect(File modDir) {
        if (!modDir.isDirectory()) {
            return new Existing(false, null);
        }
        File manifestFile = new File(modDir, "manifest.json");
        if (!manifestFile.isFile()) {
            return new Existing(false, null);
        }
        try (InputStreamReader reader = new InputStreamReader(
                new java.io.FileInputStream(manifestFile), StandardCharsets.UTF_8)) {
            JsonObject manifest = GSON.fromJson(reader, JsonObject.class);
            if (manifest == null
                    || !manifest.has("type") || !"preload-native".equals(manifest.get("type").getAsString())
                    || !manifest.has("entry") || !manifest.get("entry").isJsonPrimitive()) {
                return new Existing(false, null);
            }
            String entry = manifest.get("entry").getAsString();
            if (entry == null || entry.contains("..") || entry.startsWith("/") || !entry.endsWith(".so")) {
                return new Existing(false, null);
            }
            File entryFile = new File(modDir, entry);
            if (!entryFile.isFile() || entryFile.length() <= 0) {
                return new Existing(false, null);
            }
            String version = manifest.has("version") && manifest.get("version").isJsonPrimitive()
                    ? manifest.get("version").getAsString() : "0";
            return new Existing(true, version);
        } catch (Exception e) {
            Log.w(TAG, "Could not read installed Volt manifest", e);
            return new Existing(false, null);
        }
    }

    private static File copyAssetToCache(Context context) throws IOException {
        File dir = new File(context.getCacheDir(), "bundled_mods");
        if (!dir.isDirectory() && !dir.mkdirs()) {
            throw new IOException("Failed to create cache directory");
        }
        File out = new File(dir, VOLT_ASSET);
        try (InputStream in = context.getAssets().open(VOLT_ASSET);
             OutputStream os = new FileOutputStream(out)) {
            byte[] buffer = new byte[8192];
            int read;
            while ((read = in.read(buffer)) > 0) {
                os.write(buffer, 0, read);
            }
        } catch (IOException e) {
            //noinspection ResultOfMethodCallIgnored
            out.delete();
            throw e;
        }
        return out;
    }

    private static State readState(File modsDir) {
        File file = new File(modsDir, STATE_FILE);
        if (!file.isFile()) {
            return null;
        }
        try (InputStreamReader reader = new InputStreamReader(
                new java.io.FileInputStream(file), StandardCharsets.UTF_8)) {
            JsonObject json = GSON.fromJson(reader, JsonObject.class);
            if (json == null) {
                return null;
            }
            State state = new State();
            state.state = json.has("state") && json.get("state").isJsonPrimitive()
                    ? json.get("state").getAsString() : null;
            state.bundledVersion = json.has("bundledVersion") && json.get("bundledVersion").isJsonPrimitive()
                    ? json.get("bundledVersion").getAsString() : null;
            state.attempts = json.has("attempts") && json.get("attempts").isJsonPrimitive()
                    ? json.get("attempts").getAsInt() : 0;
            return state.state == null ? null : state;
        } catch (Exception e) {
            Log.w(TAG, "Ignoring unreadable bundled-mod state", e);
            return null;
        }
    }

    /** Written to a temp file first so an interrupted write cannot leave a corrupt state file. */
    private static void writeState(File modsDir, String stateValue, String version, int attempts) {
        JsonObject json = new JsonObject();
        json.addProperty("state", stateValue);
        json.addProperty("bundledVersion", version);
        json.addProperty("attempts", attempts);
        File tmp = new File(modsDir, STATE_FILE + ".tmp");
        File target = new File(modsDir, STATE_FILE);
        try (OutputStreamWriter writer = new OutputStreamWriter(new FileOutputStream(tmp), StandardCharsets.UTF_8)) {
            GSON.toJson(json, writer);
        } catch (IOException e) {
            Log.w(TAG, "Could not write bundled-mod state", e);
            //noinspection ResultOfMethodCallIgnored
            tmp.delete();
            return;
        }
        if (!tmp.renameTo(target)) {
            Log.w(TAG, "Could not finalize bundled-mod state");
            //noinspection ResultOfMethodCallIgnored
            tmp.delete();
        }
    }

    /** Dotted numeric comparison; non-numeric parts count as 0. */
    static int compareVersions(String left, String right) {
        String[] a = left == null ? new String[0] : left.trim().split("\\.");
        String[] b = right == null ? new String[0] : right.trim().split("\\.");
        int len = Math.max(a.length, b.length);
        for (int i = 0; i < len; i++) {
            long x = i < a.length ? parseLeadingNumber(a[i]) : 0;
            long y = i < b.length ? parseLeadingNumber(b[i]) : 0;
            if (x != y) {
                return Long.compare(x, y);
            }
        }
        return 0;
    }

    private static long parseLeadingNumber(String part) {
        int end = 0;
        while (end < part.length() && Character.isDigit(part.charAt(end))) {
            end++;
        }
        if (end == 0) {
            return 0;
        }
        try {
            return Long.parseLong(part.substring(0, end));
        } catch (NumberFormatException e) {
            return 0;
        }
    }
}
