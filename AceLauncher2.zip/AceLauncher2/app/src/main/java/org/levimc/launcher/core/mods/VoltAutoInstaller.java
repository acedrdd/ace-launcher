package org.levimc.launcher.core.mods;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.util.Log;

import org.json.JSONObject;
import org.levimc.launcher.core.versions.GameVersion;
import org.levimc.launcher.core.versions.VersionManager;
import org.levimc.launcher.ui.views.MainViewModel;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.Locale;

/**
 * Installs the bundled Volt pack (assets/bundled-mods/Ace-Volt-2.3.2.levipack) once per game
 * version, through the launcher's normal FileHandler import path. It never overwrites an existing
 * Volt, never reinstalls after the user removed it, and reports failures instead of hiding them.
 */
public final class VoltAutoInstaller {
    private static final String TAG = "VoltAutoInstaller";
    private static final String ASSET_PATH = "bundled-mods/Ace-Volt-2.3.2.levipack";
    // Game versions Volt is auto-installed for. 1.26.60 is allowed on the owner's say-so
    // (patch release of 1.26.5x); Volt itself only declares 1.26.52, so this is untested here.
    private static final String[] SUPPORTED_MINECRAFT = {"1.26.52", "1.26.60"};
    private static final String PREFS = "ace_volt_autoinstall";

    public interface Listener {
        void onInstalled();

        void onFailed(String message);
    }

    private VoltAutoInstaller() {
    }

    public static boolean isSupported(GameVersion v) {
        if (v == null) return false;
        return contains(v.versionCode) || contains(v.displayName) || contains(v.directoryName);
    }

    private static boolean contains(String s) {
        if (s == null) return false;
        for (String supported : SUPPORTED_MINECRAFT) {
            if (s.contains(supported)) return true;
        }
        return false;
    }

    // The mod loader only loads a mod whose minecraft_versions match the running game, so the
    // installed manifest must list every supported version (wildcard covers 1.26.60.x builds).
    private static java.util.List<String> versionPatterns() {
        java.util.List<String> patterns = new java.util.ArrayList<>();
        for (String supported : SUPPORTED_MINECRAFT) patterns.add(supported + "*");
        return patterns;
    }

    /** Call on the main thread after a game version is selected. */
    public static void ensureInstalled(Context context, MainViewModel viewModel,
                                       VersionManager versionManager, Listener listener) {
        if (context == null || viewModel == null || versionManager == null) return;
        GameVersion version = versionManager.getSelectedVersion();
        if (!isSupported(version) || version.modsDir == null) return;

        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String key = "done_" + version.directoryName;
        if (prefs.getBoolean(key, false)) return;

        if (isVoltPresent(version.modsDir)) {
            prefs.edit().putBoolean(key, true).apply();
            return;
        }

        File temp = new File(context.getCacheDir(), "ace_volt_autoinstall.levipack");
        try {
            copyAsset(context, temp);
        } catch (Exception e) {
            Log.e(TAG, "Bundled Volt pack is missing", e);
            if (listener != null) listener.onFailed("Bundled Volt pack could not be read");
            return;
        }

        Intent intent = new Intent();
        intent.setData(Uri.fromFile(temp));
        new FileHandler(context, viewModel, versionManager).processCatalogModDirectly(
                intent, "Volt", "DrukisMC", "2.3.2",
                versionPatterns(),
                new FileHandler.FileOperationCallback() {
                    @Override
                    public void onSuccess(int processedFiles) {
                        prefs.edit().putBoolean(key, true).apply();
                        temp.delete();
                        if (listener != null) listener.onInstalled();
                    }

                    @Override
                    public void onError(String errorMessage) {
                        // Flag stays unset so it is retried on the next launch.
                        temp.delete();
                        Log.e(TAG, "Volt install failed: " + errorMessage);
                        if (listener != null) {
                            listener.onFailed(errorMessage == null ? "Unknown error" : errorMessage);
                        }
                    }

                    @Override
                    public void onProgressUpdate(int progress) {
                    }
                });
    }

    private static boolean isVoltPresent(File modsDir) {
        File[] children = modsDir.listFiles(File::isDirectory);
        if (children == null) return false;
        for (File dir : children) {
            if (dir.getName().toLowerCase(Locale.ROOT).contains("volt")) return true;
            File manifest = new File(dir, "manifest.json");
            if (!manifest.isFile()) continue;
            try {
                String json = new String(Files.readAllBytes(manifest.toPath()), StandardCharsets.UTF_8);
                String name = new JSONObject(json).optString("name", "");
                if ("volt".equalsIgnoreCase(name.trim())) return true;
            } catch (Exception ignored) {
            }
        }
        return false;
    }

    private static void copyAsset(Context context, File dest) throws Exception {
        try (InputStream in = context.getAssets().open(ASSET_PATH);
             OutputStream out = new FileOutputStream(dest)) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        }
    }
}
